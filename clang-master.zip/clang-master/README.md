--------------
Clang
--------------

### Instruções:

- Realize o download clicando em "Download ZIP" do lado direito da página.
- 
- Descompacte o conteúdo em uma pasta separada (Certifique-se que o caminho não possua espaços)

(Versões anteriores Windows Vista)
- Vá em Iniciar -> Painel de Controle -> Sistema -> Avançado -> Variáveis de Ambiente -> Variáveis de Sistema e procure por PATH . Adicione o caminho da pasta clang-master com "\bin" no final e confirme.

(Versões após ao Windows Vista)
- Execute como administrador o arquivo Cronus.bat localizado na pasta do compilador. Irá surgir uma janela do DOS indicando
o status da operação. Caso apareça "ÊXITO", tudo ocorreu conforme o esperado. Feche a janela.

- Após isso, aceda-se a pasta do emulador e execute o arquivo Cronus.bat localizado na pasta do emulador.



